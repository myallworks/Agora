package io.metamask.androidsdk

object SDKInfo {
    const val VERSION = "0.2.1"
    const val PLATFORM = "android"
}