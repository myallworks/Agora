package io.metamask.androidsdk

data class Message(val id: String, val message: String)