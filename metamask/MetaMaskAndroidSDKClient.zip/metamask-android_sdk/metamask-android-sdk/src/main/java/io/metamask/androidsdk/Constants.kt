package io.metamask.androidsdk

const val TAG = "MM_ANDROID_SDK"
const val MESSAGE = "message"
const val KEY_EXCHANGE = "key_exchange"