package com.dev.frequenc

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MetaMaskDappApplication : Application() {}