package com.dev.frequenc

enum class DappScreen {
    CONNECT,
    ACTIONS,
    SIGN_MESSAGE,
    SEND_TRANSACTION,
    SWITCH_CHAIN
}