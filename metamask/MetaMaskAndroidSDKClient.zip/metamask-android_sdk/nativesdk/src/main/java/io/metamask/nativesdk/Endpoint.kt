package io.metamask.nativesdk

class Endpoints {
    companion object {
        const val BASE_URL = "https://metamask-sdk-socket.metafi.codefi.network"
        const val ANALYTICS = "$BASE_URL/debug"
    }
}