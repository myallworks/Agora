package io.metamask.nativesdk

const val TAG = "NATIVE_SDK"
const val MESSAGE = "message"
const val KEY_EXCHANGE = "key_exchange"